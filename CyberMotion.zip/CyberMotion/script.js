/* =========================================================================
   CyberMotion — script.js
   Vanilla ES6. No frameworks, no scroll libraries. Anime.js for tweening.
   ========================================================================= */
'use strict';

/* ============================== Utils ================================== */
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);
const lerp = (a, b, t) => a + (b - a) * t;
const mapRange = (v, inMin, inMax, outMin, outMax) => {
  const t = clamp((v - inMin) / (inMax - inMin), 0, 1);
  return outMin + t * (outMax - outMin);
};
const qs = (sel, ctx = document) => ctx.querySelector(sel);
const qsa = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const isTouch = matchMedia('(hover:none), (pointer:coarse)').matches;
const prefersReducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const hasAnime = typeof window.anime === 'function';

/** Reusable spring-ish easing string for anime.js calls. */
const SPRING = 'spring(1, 80, 10, 0)';
const EASE_OUT_EXPO = 'cubicBezier(0.16, 1, 0.3, 1)';

/** rAF ticker shared by every module that needs a per-frame update. */
class Ticker {
  constructor() {
    this.callbacks = new Set();
    this.running = false;
    this._tick = this._tick.bind(this);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.running = false;
      else if (this.callbacks.size) this.start();
    });
  }
  add(fn) {
    this.callbacks.add(fn);
    if (!this.running && !document.hidden) this.start();
    return () => this.callbacks.delete(fn);
  }
  start() {
    if (this.running) return;
    this.running = true;
    requestAnimationFrame(this._tick);
  }
  _tick(time) {
    if (!this.running) return;
    this.callbacks.forEach((fn) => fn(time));
    requestAnimationFrame(this._tick);
  }
}
const ticker = new Ticker();

/** Runs `fn` when the browser is idle (or after a short fallback timeout),
 *  so non-critical decoration never competes with first paint. */
function whenIdle(fn) {
  if ('requestIdleCallback' in window) requestIdleCallback(fn, { timeout: 1200 });
  else setTimeout(fn, 200);
}

/* ============================ Split text ================================ */
/**
 * Wraps the text of every `[data-line]` child inside `root` into individual
 * `.split-char` spans, keeping the original element as an overflow-hidden
 * line mask. Spaces are preserved as non-breaking so words don't collapse.
 */
function splitLines(root) {
  const lines = qsa('[data-line]', root);
  lines.forEach((line) => {
    const text = line.textContent;
    line.textContent = '';
    line.setAttribute('aria-label', text);
    [...text].forEach((char) => {
      const span = document.createElement('span');
      span.className = 'split-char';
      span.textContent = char === ' ' ? '\u00A0' : char;
      line.appendChild(span);
    });
  });
  return lines;
}

/* ============================== Preloader ================================ */
class Preloader {
  constructor(onDone) {
    this.el = qs('#preloader');
    this.fill = qs('#preloaderFill');
    this.label = qs('#preloaderLabel');
    this.onDone = onDone;
    this.progress = { value: 0 };
    this._run();
  }
  _run() {
    const finish = () => {
      if (hasAnime) {
        anime({
          targets: this.progress,
          value: 100,
          duration: 900,
          easing: EASE_OUT_EXPO,
          update: () => this._render(),
          complete: () => this._hide(),
        });
      } else {
        this._render(100);
        this._hide();
      }
    };
    // Simulated load progress up to ~85%, then snap to 100 on window load.
    if (hasAnime) {
      anime({
        targets: this.progress,
        value: 85,
        duration: 1400,
        easing: 'easeOutQuad',
        update: () => this._render(),
      });
    }
    if (document.readyState === 'complete') finish();
    else window.addEventListener('load', finish, { once: true });
  }
  _render() {
    const v = Math.round(this.progress.value);
    if (this.fill) this.fill.style.width = v + '%';
    if (this.label) this.label.textContent = `INITIALIZING — ${v}%`;
  }
  _hide() {
    this.el.classList.add('is-hidden');
    document.body.style.overflow = '';
    setTimeout(() => {
      this.el.style.display = 'none';
      this.onDone && this.onDone();
    }, 650);
  }
}

/* ============================ Custom cursor =============================== */
class CustomCursor {
  constructor() {
    this.ring = qs('#cursorRing');
    this.dot = qs('#cursorDot');
    if (isTouch || !this.ring || !this.dot) {
      document.body.classList.add('no-custom-cursor');
      return;
    }
    this.pos = { x: innerWidth / 2, y: innerHeight / 2 };
    this.ringPos = { ...this.pos };
    this._bind();
    ticker.add(() => this._render());
  }
  _bind() {
    window.addEventListener(
      'mousemove',
      (e) => {
        this.pos.x = e.clientX;
        this.pos.y = e.clientY;
        this.dot.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0) translate(-50%,-50%)`;
      },
      { passive: true }
    );

    const hoverSelector = 'a, button, [data-tilt], [data-cursor-hover], input, textarea';
    document.addEventListener('mouseover', (e) => {
      const magnetic = e.target.closest('[data-magnetic]');
      const hoverable = e.target.closest(hoverSelector);
      this.ring.classList.toggle('is-magnetic', !!magnetic);
      this.ring.classList.toggle('is-hover', !!hoverable && !magnetic);
    });
    document.addEventListener('mouseout', (e) => {
      const toEl = e.relatedTarget;
      if (toEl && toEl.closest && toEl.closest('[data-magnetic], ' + hoverSelector)) return;
      this.ring.classList.remove('is-hover', 'is-magnetic');
    });

    this.pressScale = 1;
    this.pressTarget = 1;
    window.addEventListener('mousedown', () => (this.pressTarget = 0.82));
    window.addEventListener('mouseup', () => (this.pressTarget = 1));
  }
  _render() {
    this.ringPos.x = lerp(this.ringPos.x, this.pos.x, 0.18);
    this.ringPos.y = lerp(this.ringPos.y, this.pos.y, 0.18);
    this.pressScale = lerp(this.pressScale, this.pressTarget, 0.3);
    this.ring.style.transform =
      `translate3d(${this.ringPos.x}px, ${this.ringPos.y}px, 0) translate(-50%,-50%) scale(${this.pressScale})`;
  }
}

/* ============================ Magnetic buttons ============================= */
class MagneticController {
  constructor() {
    if (isTouch) return;
    this.els = qsa('[data-magnetic]');
    this.els.forEach((el) => this._bind(el));
  }
  _bind(el) {
    const strength = 0.4;
    el.style.willChange = 'transform';
    el.addEventListener('mousemove', (e) => {
      const r = el.getBoundingClientRect();
      const relX = e.clientX - (r.left + r.width / 2);
      const relY = e.clientY - (r.top + r.height / 2);
      const x = relX * strength;
      const y = relY * strength;
      if (hasAnime) {
        anime({ targets: el, translateX: x, translateY: y, duration: 400, easing: EASE_OUT_EXPO });
      } else {
        el.style.transform = `translate(${x}px, ${y}px)`;
      }
    });
    el.addEventListener('mouseleave', () => {
      if (hasAnime) {
        anime({ targets: el, translateX: 0, translateY: 0, duration: 700, easing: SPRING });
      } else {
        el.style.transform = '';
      }
    });
  }
}

/* ============================ Smooth scroll engine ========================= */
/**
 * Hand-rolled inertia scrolling. Desktop wheel events are intercepted and
 * accumulated into a target position; a requestAnimationFrame loop eases the
 * real document scrollTop toward that target every frame. Because we move
 * the actual window scroll position (not a transformed proxy layer),
 * position:sticky, IntersectionObserver and getBoundingClientRect all keep
 * working exactly as the browser expects. Touch devices keep native
 * momentum scrolling, which is already tuned by the OS.
 */
class SmoothScroll {
  constructor() {
    this.current = window.scrollY;
    this.target = window.scrollY;
    this.ease = 0.09;
    this.wheelMultiplier = 1;
    this.maxScroll = this._getMaxScroll();
    this.idleFrames = 0;
    this.listeners = new Set();

    window.addEventListener('resize', () => (this.maxScroll = this._getMaxScroll()), { passive: true });

    if (!isTouch) {
      window.addEventListener('wheel', (e) => this._onWheel(e), { passive: false });
    }
    // Let native sources (keyboard, scrollbar drag, touch, anchor jumps not
    // routed through us) resync our target so we never fight the browser.
    window.addEventListener(
      'scroll',
      () => {
        if (this._selfScrolling) return;
        this.target = window.scrollY;
        this.current = window.scrollY;
      },
      { passive: true }
    );

    ticker.add(() => this._render());
  }

  _getMaxScroll() {
    return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  }

  _onWheel(e) {
    e.preventDefault();
    this.target = clamp(this.target + e.deltaY * this.wheelMultiplier, 0, this.maxScroll);
  }

  /** Smoothly animate to an absolute Y position (used by anchor navigation). */
  scrollTo(y) {
    const target = clamp(y, 0, this.maxScroll);
    if (isTouch) {
      // A one-off explicit jump (nav tap) is fine on touch — it's the
      // continuous per-frame writes in _render() that fight native
      // momentum scrolling, not a single navigational scroll.
      this.target = target;
      this.current = target;
      window.scrollTo({ top: target, behavior: 'smooth' });
      return;
    }
    this.target = target;
  }

  onScroll(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  _render() {
    if (isTouch) {
      // Native touch/momentum scrolling is authoritative here — we only
      // read the real position for other modules (parallax, gallery,
      // nav shrink, etc.) and never call scrollTo, which is what was
      // causing scrolling to lock up on touch devices.
      this.current = window.scrollY;
      this.target = this.current;
      this.listeners.forEach((fn) => fn(this.current, this.maxScroll));
      return;
    }

    const diff = this.target - this.current;
    if (Math.abs(diff) < 0.05) {
      this.current = this.target;
    } else {
      this.current = lerp(this.current, this.target, this.ease);
    }
    this._selfScrolling = true;
    window.scrollTo(0, this.current);
    this._selfScrolling = false;

    this.listeners.forEach((fn) => fn(this.current, this.maxScroll));
  }
}

/* ============================ Mouse spotlight ============================== */
class MouseSpotlight {
  constructor() {
    this.el = qs('#spotlight');
    this.x = innerWidth / 2;
    this.y = innerHeight * 0.3;
    this.tx = this.x;
    this.ty = this.y;
    if (!this.el || isTouch) return;
    window.addEventListener(
      'mousemove',
      (e) => {
        this.tx = e.clientX;
        this.ty = e.clientY;
      },
      { passive: true }
    );
    ticker.add(() => this._render());
  }
  _render() {
    this.x = lerp(this.x, this.tx, 0.12);
    this.y = lerp(this.y, this.ty, 0.12);
    this.el.style.setProperty('--sx', this.x + 'px');
    this.el.style.setProperty('--sy', this.y + 'px');
  }
}

/* ============================ Starfield canvas ============================= */
class StarsField {
  constructor() {
    this.canvas = qs('#starsCanvas');
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.stars = [];
    this.scrollOffset = 0;
    this._resize();
    window.addEventListener('resize', () => this._resize(), { passive: true });
    if (!prefersReducedMotion) ticker.add((t) => this._render(t));
    else this._render(0);
  }
  _resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.w = this.canvas.width = innerWidth * dpr;
    this.h = this.canvas.height = innerHeight * dpr;
    this.canvas.style.width = innerWidth + 'px';
    this.canvas.style.height = innerHeight + 'px';
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.round((innerWidth * innerHeight) / 9000);
    this.stars = Array.from({ length: count }, () => ({
      x: Math.random() * innerWidth,
      y: Math.random() * innerHeight,
      r: Math.random() * 1.4 + 0.2,
      speed: Math.random() * 0.4 + 0.05,
      phase: Math.random() * Math.PI * 2,
    }));
  }
  setScroll(y) {
    this.scrollOffset = y;
  }
  _render(t) {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const time = t * 0.001;
    this.stars.forEach((s) => {
      const drift = (this.scrollOffset * s.speed * 0.05) % innerHeight;
      const y = (s.y + drift) % innerHeight;
      const twinkle = 0.5 + Math.sin(time * 1.5 + s.phase) * 0.5;
      ctx.beginPath();
      ctx.arc(s.x, y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(248,250,255,${0.15 + twinkle * 0.55})`;
      ctx.fill();
    });
  }
}

/* ============================ Floating particles =========================== */
class ParticlesField {
  constructor() {
    this.root = qs('#particlesField');
    if (!this.root || prefersReducedMotion) return;
    const colors = ['var(--cyan)', 'var(--purple)', 'var(--magenta)'];
    const count = innerWidth < 768 ? 16 : 34;
    for (let i = 0; i < count; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      const size = Math.random() * 3 + 1.5;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.left = Math.random() * 100 + 'vw';
      p.style.top = Math.random() * 100 + 'vh';
      p.style.color = colors[i % colors.length];
      p.style.opacity = (Math.random() * 0.5 + 0.2).toFixed(2);
      this.root.appendChild(p);
      this._float(p);
    }
  }
  _float(p) {
    if (!hasAnime) return;
    const driftX = (Math.random() - 0.5) * 160;
    const driftY = -(Math.random() * 220 + 80);
    const duration = Math.random() * 9000 + 7000;
    anime({
      targets: p,
      translateX: [0, driftX],
      translateY: [0, driftY],
      opacity: [p.style.opacity, 0],
      duration,
      easing: 'easeInOutSine',
      delay: Math.random() * 4000,
      complete: () => {
        p.style.left = Math.random() * 100 + 'vw';
        p.style.top = 100 + Math.random() * 20 + 'vh';
        p.style.opacity = (Math.random() * 0.5 + 0.2).toFixed(2);
        this._float(p);
      },
    });
  }
}

/* ============================ Parallax blobs / layers ======================= */
class ParallaxController {
  constructor() {
    this.els = qsa('[data-parallax]').map((el) => ({
      el,
      factor: parseFloat(el.dataset.parallax) || 0.05,
    }));
  }
  update(scrollY) {
    this.els.forEach(({ el, factor }) => {
      el.style.transform = `translate3d(0, ${scrollY * factor * -1}px, 0)`;
    });
  }
}

/* ============================ Scroll-driven 3D gyroscope ===================== */
/**
 * A real CSS 3D object — three rings tilted on different axes inside a
 * `transform-style: preserve-3d` parent, viewed through `perspective` on its
 * ancestor — whose own rotateX/rotateY/rotateZ are driven by scroll
 * progress through the whole page, then smoothed with `lerp` for a heavy,
 * physical feel rather than a 1:1 jitter-prone mapping.
 */
class ScrollGyro {
  constructor() {
    this.el = qs('#heroGyro');
    if (!this.el) return;
    this.rx = 0;
    this.ry = 20;
    this.rz = 0;
    this.tx = 0;
    this.ty = 20;
    this.tz = 0;
    ticker.add(() => this._render());
  }
  update(scrollY, maxScroll) {
    if (!this.el) return;
    const progress = maxScroll > 0 ? clamp(scrollY / maxScroll, 0, 1) : 0;
    this.tx = progress * 360 * 2;
    this.ty = 20 + progress * 360 * 3;
    this.tz = progress * 50;
  }
  _render() {
    if (!this.el) return;
    this.rx = lerp(this.rx, this.tx, 0.05);
    this.ry = lerp(this.ry, this.ty, 0.05);
    this.rz = lerp(this.rz, this.tz, 0.05);
    this.el.style.transform =
      `translate3d(-50%,-50%,0) rotateX(${this.rx}deg) rotateY(${this.ry}deg) rotateZ(${this.rz}deg)`;
  }
}

/* ============================ Navigation controller ========================= */
class NavController {
  constructor(smoothScroll) {
    this.smoothScroll = smoothScroll;
    this.navbar = qs('#navbar');
    this.toggle = qs('#navToggle');
    this.mobile = qs('#navMobile');
    this.links = qsa('[data-nav-link][data-section]');
    this.sections = this.links
      .map((link) => qs('#' + link.dataset.section))
      .filter(Boolean);

    this._bindShrink();
    this._bindToggle();
    this._bindAnchors();
    this._bindActiveSection();
  }

  _bindShrink() {
    let last = -1;
    this.smoothScroll.onScroll((y) => {
      const scrolled = y > 40;
      if (scrolled !== last) {
        this.navbar.classList.toggle('is-scrolled', scrolled);
        last = scrolled;
      }
    });
  }

  _bindToggle() {
    if (!this.toggle) return;
    this.toggle.addEventListener('click', () => {
      const open = this.toggle.classList.toggle('is-open');
      this.mobile.classList.toggle('is-open', open);
    });
    qsa('a', this.mobile).forEach((a) =>
      a.addEventListener('click', () => {
        this.toggle.classList.remove('is-open');
        this.mobile.classList.remove('is-open');
      })
    );
  }

  _bindAnchors() {
    qsa('[data-scroll-link]').forEach((link) => {
      link.addEventListener('click', (e) => {
        const hash = link.getAttribute('href');
        if (!hash || hash.charAt(0) !== '#') return;
        const target = qs(hash);
        if (!target) return;
        e.preventDefault();
        const navHeight = qs('#navbar').offsetHeight;
        const y = target.getBoundingClientRect().top + window.scrollY - navHeight + 1;
        this.smoothScroll.scrollTo(y);
      });
    });
  }

  _bindActiveSection() {
    if (!('IntersectionObserver' in window) || this.sections.length === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const id = entry.target.id;
          this.links.forEach((link) =>
            link.classList.toggle('is-active', link.dataset.section === id)
          );
        });
      },
      { rootMargin: '-45% 0px -50% 0px', threshold: 0 }
    );
    this.sections.forEach((s) => observer.observe(s));
  }
}

/* ============================ Generic reveal-on-scroll ======================= */
class RevealController {
  constructor() {
    this.items = qsa('[data-reveal]');
    if (!('IntersectionObserver' in window)) {
      this.items.forEach((el) => this._play(el));
      return;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          this._play(entry.target);
          obs.unobserve(entry.target);
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -8% 0px' }
    );
    this.items.forEach((el) => observer.observe(el));
  }

  _play(el) {
    const type = el.dataset.revealType || 'fade-up';
    const delay = parseInt(el.dataset.revealDelay || '0', 10);
    if (!hasAnime || prefersReducedMotion) {
      el.style.opacity = 1;
      return;
    }
    const presets = {
      'fade-up': { translateY: [28, 0], opacity: [0, 1] },
      'fade-left': { translateX: [36, 0], opacity: [0, 1] },
      'scale-in': { scale: [0.9, 1], opacity: [0, 1] },
    };
    anime({
      targets: el,
      ...(presets[type] || presets['fade-up']),
      duration: 900,
      delay,
      easing: EASE_OUT_EXPO,
    });
  }
}

/* ============================ Counter animation ============================== */
class CounterController {
  constructor() {
    this.items = qsa('.counter__value');
    if (!('IntersectionObserver' in window)) {
      this.items.forEach((el) => this._play(el));
      return;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          this._play(entry.target);
          obs.unobserve(entry.target);
        });
      },
      { threshold: 0.4 }
    );
    this.items.forEach((el) => observer.observe(el));
  }
  _play(el) {
    const end = parseFloat(el.dataset.count || '0');
    const suffix = el.dataset.suffix || '';
    if (!hasAnime || prefersReducedMotion) {
      el.textContent = end + suffix;
      return;
    }
    const obj = { value: 0 };
    anime({
      targets: obj,
      value: end,
      duration: 1600,
      round: 1,
      easing: EASE_OUT_EXPO,
      update: () => (el.textContent = Math.round(obj.value) + suffix),
    });
  }
}

/* ============================ SVG stroke draw (reveal) ======================= */
class SvgDrawController {
  constructor() {
    this.paths = qsa('[data-svg-draw] path');
    this.paths.forEach((path) => {
      const length = path.getTotalLength();
      path.style.strokeDasharray = length;
      path.style.strokeDashoffset = length;
    });
    if (!('IntersectionObserver' in window)) {
      this.paths.forEach((p) => this._play(p));
      return;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          this._play(entry.target);
          obs.unobserve(entry.target);
        });
      },
      { threshold: 0.4 }
    );
    this.paths.forEach((p) => observer.observe(p));
  }
  _play(path) {
    if (!hasAnime || prefersReducedMotion) {
      path.style.strokeDashoffset = 0;
      return;
    }
    anime({
      targets: path,
      strokeDashoffset: 0,
      duration: 1600,
      easing: EASE_OUT_EXPO,
    });
  }
}

/* ============================ Timeline circuit (scroll interpolation) ========= */
/**
 * The circuit trace is driven directly by scroll progress through the
 * section rather than by time: an Anime.js instance is created once with
 * autoplay disabled, then `.seek()` is called every frame with a duration
 * fraction derived from scroll position — genuine scroll interpolation.
 */
class TimelineCircuit {
  constructor() {
    this.section = qs('#timeline');
    this.path = qs('#circuitPath');
    if (!this.section || !this.path || !hasAnime) return;

    const length = this.path.getTotalLength ? this.path.getTotalLength() : 1000;
    this.path.style.strokeDasharray = length;
    this.path.style.strokeDashoffset = length;

    this.timeline = anime({
      targets: this.path,
      strokeDashoffset: [length, 0],
      easing: 'linear',
      autoplay: false,
      duration: 1000,
    });

    this.active = false;
    if ('IntersectionObserver' in window) {
      new IntersectionObserver((entries) => {
        entries.forEach((e) => (this.active = e.isIntersecting));
      }).observe(this.section);
    } else {
      this.active = true;
    }
  }
  update() {
    if (!this.active || !this.timeline) return;
    const rect = this.section.getBoundingClientRect();
    const total = rect.height - window.innerHeight;
    const progress = mapRange(-rect.top, 0, Math.max(total, 1), 0, 1);
    this.timeline.seek(progress * this.timeline.duration);
  }
}

/* ============================ Timeline item reveal (blur transition) ========= */
class TimelineItemsController {
  constructor() {
    this.items = qsa('.timeline-item');
    if (!('IntersectionObserver' in window)) {
      this.items.forEach((el) => this._play(el));
      return;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          this._play(entry.target);
          obs.unobserve(entry.target);
        });
      },
      { threshold: 0.35 }
    );
    this.items.forEach((el) => observer.observe(el));
  }
  _play(el) {
    if (!hasAnime || prefersReducedMotion) {
      el.style.filter = 'none';
      el.style.opacity = 1;
      return;
    }
    anime({
      targets: el,
      opacity: [0, 1],
      translateY: [40, 0],
      filter: ['blur(6px)', 'blur(0px)'],
      duration: 1000,
      easing: EASE_OUT_EXPO,
    });
  }
}

/* ============================ Mouse tilt (feature + gallery cards) =========== */
class TiltController {
  constructor() {
    if (isTouch) return;
    this.els = qsa('[data-tilt]');
    this.els.forEach((el) => this._bind(el));
  }
  _bind(el) {
    const max = 10;
    el.addEventListener('mousemove', (e) => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      const rotateY = (px - 0.5) * max * 2;
      const rotateX = (0.5 - py) * max * 2;
      el.style.setProperty('--mx', px * 100 + '%');
      el.style.setProperty('--my', py * 100 + '%');
      el.style.transform = `perspective(900px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(0) scale(1.015)`;
    });
    el.addEventListener('mouseleave', () => {
      if (hasAnime) {
        anime({
          targets: el,
          rotateX: 0,
          rotateY: 0,
          scale: 1,
          duration: 700,
          easing: SPRING,
        });
      } else {
        el.style.transform = '';
      }
    });
  }
}

/* ============================ Icon float / morphing gradient ================= */
class IconSpin {
  constructor() {
    if (!hasAnime) return;
    const icons = qsa('[data-icon-spin]');

    // Ambient idle motion: a gentle scale breathe. Scale stays visually
    // correct even while the parent card is mid-tilt, unlike a continuous
    // rotation, which would render as a warped ellipse inside a live 3D
    // perspective transform.
    if (!prefersReducedMotion) {
      icons.forEach((icon, i) => {
        anime({
          targets: icon,
          scale: [1, 1.06, 1],
          duration: 3200 + i * 200,
          easing: 'easeInOutSine',
          loop: true,
        });
      });
    }

    // The actual spin is a one-shot hover flourish instead of a permanent
    // loop, so it never has to coexist with the tilt transform for more
    // than a fraction of a second.
    if (prefersReducedMotion) return;
    icons.forEach((icon) => {
      const card = icon.closest('.feature-card');
      if (!card) return;
      card.addEventListener('mouseenter', () => {
        anime({
          targets: icon,
          rotate: '+=360',
          duration: 650,
          easing: EASE_OUT_EXPO,
        });
      });
    });
  }
}

class MorphingGradient {
  constructor() {
    this.blobs = qsa('.bg-blob');
    if (!hasAnime || prefersReducedMotion || this.blobs.length === 0) return;
    const hues = [
      ['#8A2EFF', '#00E5FF'],
      ['#00E5FF', '#FF2DA6'],
      ['#FF2DA6', '#8A2EFF'],
    ];
    this.blobs.forEach((blob, i) => {
      const state = { t: 0 };
      anime({
        targets: state,
        t: 1,
        duration: 9000 + i * 1500,
        direction: 'alternate',
        loop: true,
        easing: 'easeInOutSine',
        update: () => {
          blob.style.background = `linear-gradient(${state.t * 360}deg, ${hues[i % hues.length][0]}, ${hues[i % hues.length][1]})`;
        },
      });
    });
  }
}

/* ============================ Horizontal gallery ============================= */
/**
 * The section height is padded with a spacer so the sticky viewport stays
 * pinned long enough to translate the track exactly from its start to end
 * position. Scale + perspective per card are derived from each card's
 * distance to the viewport's horizontal center every frame while the
 * section is on screen (guarded by IntersectionObserver so idle sections
 * cost nothing).
 */
class GalleryController {
  constructor() {
    this.section = qs('#gallery');
    this.viewport = qs('.gallery__viewport');
    this.track = qs('#galleryTrack');
    this.spacer = qs('#gallerySpacer');
    this.progressFill = qs('#galleryProgress');
    this.cards = qsa('.gallery-card', this.track);
    if (!this.section || !this.track || !this.spacer) return;

    this.active = false;
    this.distance = 0;
    this.progress = 0;

    this._measure();
    window.addEventListener('resize', () => this._measure(), { passive: true });

    if ('IntersectionObserver' in window) {
      new IntersectionObserver((entries) => {
        entries.forEach((e) => (this.active = e.isIntersecting));
      }).observe(this.section);
    } else {
      this.active = true;
    }

    if (!isTouch) {
      this.cards.forEach((card) => {
        card.addEventListener('mousemove', (e) => {
          const r = card.getBoundingClientRect();
          card.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
          card.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
        });
      });
    }
  }

  _measure() {
    const trackWidth = this.track.scrollWidth;
    const viewportWidth = this.viewport.clientWidth;
    this.distance = Math.max(trackWidth - viewportWidth, 0);
    this.spacer.style.height = this.distance + 'px';
  }

  update() {
    if (!this.active || this.distance <= 0) return;

    const rect = this.section.getBoundingClientRect();
    const headHeight = rect.height - this.distance - window.innerHeight;
    const scrolledIntoPin = -rect.top - headHeight;
    this.progress = clamp(scrolledIntoPin / this.distance, 0, 1);

    this.track.style.transform = `translate3d(${-this.progress * this.distance}px,0,0)`;
    if (this.progressFill) {
      this.progressFill.style.transform = `scaleX(${0.2 + this.progress * 0.8})`;
    }

    const viewportRect = this.viewport.getBoundingClientRect();
    const centerX = viewportRect.left + viewportRect.width / 2;
    this.cards.forEach((card) => {
      const cardRect = card.getBoundingClientRect();
      const cardCenter = cardRect.left + cardRect.width / 2;
      const dist = cardCenter - centerX;
      const norm = clamp(Math.abs(dist) / (viewportRect.width / 2), 0, 1);
      const scale = mapRange(norm, 0, 1, 1.06, 0.86);
      const rotateY = mapRange(dist, -viewportRect.width / 2, viewportRect.width / 2, 14, -14);
      const translateZ = mapRange(norm, 0, 1, 0, -80);
      card.style.transform = `perspective(1400px) rotateY(${rotateY}deg) translateZ(${translateZ}px) scale(${scale})`;
      card.style.opacity = mapRange(norm, 0, 1, 1, 0.55);
    });
  }
}

/* ============================ Footer huge-type reveal ========================= */
class FooterReveal {
  constructor() {
    this.el = qs('.footer__huge');
    if (!this.el) return;
    if (!('IntersectionObserver' in window) || !hasAnime || prefersReducedMotion) {
      if (this.el) this.el.style.opacity = 1;
      return;
    }
    new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          anime({
            targets: this.el,
            opacity: [0, 1],
            translateY: [60, 0],
            duration: 1200,
            easing: EASE_OUT_EXPO,
          });
          obs.disconnect();
        });
      },
      { threshold: 0.3 }
    ).observe(this.el);
  }
}

/* ============================ Animated logo mark =============================== */
class LogoAnimator {
  constructor() {
    this.marks = qsa('.navbar__logo path, .footer__brand-mark path');
    if (!hasAnime || prefersReducedMotion) return;
    this.marks.forEach((path, i) => {
      if (!path.getTotalLength) return;
      const length = path.getTotalLength();
      path.style.strokeDasharray = length;
      path.style.strokeDashoffset = length;
      anime({
        targets: path,
        strokeDashoffset: 0,
        duration: 1400,
        delay: 300 + i * 120,
        easing: EASE_OUT_EXPO,
      });
    });
  }
}

/* ============================ Signature glitch burst =========================== */
class GlitchController {
  constructor() {
    this.host = qs('.glitch-host');
    if (!this.host || prefersReducedMotion) return;
    this._loop();
    this.host.addEventListener('mouseenter', () => this._burst());
  }
  _loop() {
    const delay = 5000 + Math.random() * 4000;
    setTimeout(() => {
      this._burst();
      this._loop();
    }, delay);
  }
  _burst() {
    if (this.host.classList.contains('is-glitching')) return;
    this.host.classList.add('is-glitching');
    setTimeout(() => this.host.classList.remove('is-glitching'), 420);
  }
}

/* ============================ Hero letter-reveal intro ======================== */
class HeroIntro {
  constructor() {
    this.titleEl = qs('#heroTitle');
    this.lines = this.titleEl ? splitLines(this.titleEl) : [];
    this.trailing = qsa('#heroTag, #heroSubtitle, #heroActions');
  }
  play() {
    if (!hasAnime || prefersReducedMotion || this.lines.length === 0) {
      this.lines.forEach((line) => (line.style.opacity = 1));
      this.trailing.forEach((el) => (el.style.opacity = 1));
      return;
    }
    const tl = anime.timeline({ easing: EASE_OUT_EXPO });
    this.lines.forEach((line, i) => {
      const chars = qsa('.split-char', line);
      tl.add(
        {
          targets: chars,
          translateY: ['110%', '0%'],
          rotateZ: [8, 0],
          opacity: [0, 1],
          duration: 900,
          delay: anime.stagger(26),
          easing: SPRING,
        },
        i === 0 ? 0 : '-=650'
      );
    });
    tl.add(
      {
        targets: this.trailing,
        translateY: [24, 0],
        opacity: [0, 1],
        duration: 800,
        delay: anime.stagger(100),
      },
      '-=400'
    );
  }
}

/* ============================ App bootstrap =================================== */
class App {
  constructor() {
    document.body.style.overflow = 'hidden';
    this.heroIntro = new HeroIntro();

    new Preloader(() => {
      this.heroIntro.play();
    });

    this.cursor = new CustomCursor();
    this.magnetic = new MagneticController();
    this.spotlight = new MouseSpotlight();
    this.parallax = new ParallaxController();
    this.gyro = new ScrollGyro();

    this.smoothScroll = new SmoothScroll();
    this.nav = new NavController(this.smoothScroll);

    this.reveal = new RevealController();
    this.counters = new CounterController();
    this.svgDraw = new SvgDrawController();
    this.timelineCircuit = new TimelineCircuit();
    this.timelineItems = new TimelineItemsController();
    this.tilt = new TiltController();
    this.iconSpin = new IconSpin();
    this.morphGradient = new MorphingGradient();
    this.gallery = new GalleryController();
    this.footerReveal = new FooterReveal();
    this.logo = new LogoAnimator();
    this.glitch = new GlitchController();

    // Purely decorative and safe to defer — keeps first paint unblocked.
    whenIdle(() => {
      this.particles = new ParticlesField();
      this.stars = new StarsField();
      this._wireDeferredScroll();
    });

    this._wireScroll();
    this._bindEscape();
  }

  _wireDeferredScroll() {
    this.smoothScroll.onScroll((y) => this.stars && this.stars.setScroll(y));
  }

  _bindEscape() {
    window.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      const toggle = qs('#navToggle');
      const mobile = qs('#navMobile');
      if (toggle && mobile && mobile.classList.contains('is-open')) {
        toggle.classList.remove('is-open');
        mobile.classList.remove('is-open');
      }
    });
  }

  _wireScroll() {
    this.smoothScroll.onScroll((y, max) => {
      this.parallax.update(y);
      this.gyro.update(y, max);
      this.gallery.update();
      this.timelineCircuit.update();
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new App());
} else {
  new App();
}
