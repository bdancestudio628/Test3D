# CyberMotion

A fullscreen cyberpunk scroll experience built with nothing but HTML5, CSS3,
vanilla ES6 and Anime.js. No build step, no framework, no scroll library —
open `index.html` and it runs.

## Tech stack

- HTML5
- CSS3 (custom properties, no preprocessor)
- Vanilla JavaScript (ES6 classes, no bundler)
- [Anime.js](https://animejs.com) v3.2.2 via CDN — pinned to the last stable
  UMD (`<script src>`-friendly) release rather than `@latest`, since Anime.js
  v4 is ESM-only with a different API and would silently break a plain
  `<script>` include.

## Running it

There's nothing to install. Either:

- Open `index.html` directly in a browser, or
- Serve the folder locally (recommended, so the Google Fonts `<link>` and
  relative asset paths behave exactly like production):
  ```bash
  cd CyberMotion
  python3 -m http.server 8080
  # then visit http://localhost:8080
  ```

## File structure

```
CyberMotion/
  index.html        Markup for every section, the preloader, cursor and background layers
  style.css          All styling — tokens, components, responsive rules
  script.js          All behavior — scroll engine, cursor, animations, controllers
  assets/
    logo.svg         The hex brand mark used in the nav and footer
    grid.svg         The tileable line pattern behind the animated grid floor
  README.md          This file
```

There is no `noise.png` — the film-grain texture in the background is
generated entirely in CSS (`.bg-noise` in `style.css`), so there's nothing to
ship or load for it.

## How the moving parts fit together

Everything in `script.js` is a small, single-purpose ES6 class instantiated
once from `App`, and a shared `Ticker` (a single `requestAnimationFrame` loop)
that every module subscribes to. Nothing runs its own independent rAF loop.

**Scroll engine.** `SmoothScroll` is a hand-rolled inertia scroller: desktop
`wheel` events are intercepted and accumulated into a target position, and a
`requestAnimationFrame` loop eases the *real* `window.scrollY` toward that
target every frame (`window.scrollTo`). Because the actual document scroll
position moves — instead of faking scroll with a transformed content wrapper,
the way some libraries do — `position: sticky`, `IntersectionObserver` and
`getBoundingClientRect()` all keep working exactly as the browser expects,
with zero extra plumbing. Touch devices are left on native momentum
scrolling, which is already better-tuned per-OS than anything we'd reinvent.

**Horizontal gallery (Section 2).** The section height is padded with a
JS-measured spacer so the sticky viewport stays pinned for exactly as long as
it takes to translate the track from start to end. Card scale, perspective
rotation and opacity are recomputed every frame *only* while the section is
near the viewport (gated by `IntersectionObserver`), so idle sections cost
nothing.

**Timeline circuit (Section 3).** The trace is drawn with genuine scroll
interpolation: an Anime.js instance is created once with `autoplay: false`,
and `.seek()` is called every frame with a duration fraction derived from
scroll position — the animation's playhead *is* the scroll position, not a
time-based tween that merely starts on scroll.

**Custom cursor, magnetism, tilt.** All pointer-driven effects (the
ring/dot cursor, magnetic buttons, 3D tilt on feature cards, the mouse
spotlight) read the same `clientX/clientY`, each smoothed independently with
its own `lerp`, and each writes only to `transform`/CSS custom properties —
never `top`/`left` — to stay on the GPU-accelerated path.

**Performance choices.** The shared ticker pauses on
`visibilitychange` (a hidden tab does zero work), the floating particle field
and starfield canvas are deferred with `requestIdleCallback` so they never
compete with first paint, all scroll listeners are `{ passive: true }` except
the one that needs `preventDefault()`, and every animated property is
`transform`/`opacity`/`filter` to avoid layout thrashing.

**Accessibility.** `prefers-reduced-motion: reduce` disables the decorative
loops (particles, icon spin, ambient glitch, morphing gradients) and swaps
scroll/entrance animations for an instant, fully-visible end state. Interactive
elements keep a visible `:focus-visible` outline even though the custom
cursor hides the system pointer for mouse users.

## Customizing

- **Palette / feel** — everything runs off the CSS custom properties at the
  top of `style.css` (`--bg`, `--purple`, `--cyan`, `--magenta`, `--white`,
  glow and glass tokens). Change those and the whole page re-themes.
- **Copy** — section content lives directly in `index.html`; there's no data
  layer or templating.
- **Gallery cards / timeline entries / feature cards** — each is a repeated
  markup block in `index.html`; copy a block and the existing JS controllers
  (`GalleryController`, `TimelineItemsController`, `TiltController`) pick up
  new instances automatically since they query by class/attribute, not by
  fixed count.

## Known limitations

- The custom scroll engine intercepts `wheel` on desktop only; it doesn't
  attempt to smooth trackpad-momentum or touch scrolling, which is
  intentional (native mobile scrolling is already well-tuned).
- Extremely short viewports (landscape phones) may crowd the hero; the
  `orientation: landscape` breakpoint relaxes vertical spacing but hasn't
  been tuned against every real device.
